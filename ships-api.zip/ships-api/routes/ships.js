const express = require("express");
const { body, validationResult } = require("express-validator");
const { v4: uuidv4 } = require("uuid");

const app = express.app();

let ships = [];

app.get("/", (req, res) => {
  res.status(200).json(ships);
});

app.post(
  "/",
  [
    body("name").isString().notEmpty().withMessage("Name is required"),
    body("email").isEmail().withMessage("Valid email is required"),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, email } = req.body;
    const newShip = {
      id: uuidv4(),
      name,
      email,
      createdAt: new Date().toISOString(),
    };
    ships.push(newShip);
    res.status(201).json(newShip);
  }
);

app.get("/:id", (req, res) => {
  const ship = ships.find((s) => s.id === req.params.id);
  if (!ship) return res.status(404).json({ message: "Ship not found" });
  res.status(200).json(ship);
});

app.put(
  "/:id",
  [
    body("name").optional().isString(),
    body("email").optional().isEmail(),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const shipIndex = ships.findIndex((s) => s.id === req.params.id);
    if (shipIndex === -1) return res.status(404).json({ message: "Ship not found" });

    ships[shipIndex] = { ...ships[shipIndex], ...req.body };
    res.status(200).json(ships[shipIndex]);
  }
);

app.delete("/:id", (req, res) => {
  const shipIndex = ships.findIndex((s) => s.id === req.params.id);
  if (shipIndex === -1) return res.status(404).json({ message: "Ship not found" });

  const deletedShip = ships.splice(shipIndex, 1);
  res.status(200).json({ message: "Ship deleted", ship: deletedShip[0] });
});

module.exports = app;
